#!/bin/bash

HELP_FILE="/opt/scripts/backup_help"

# Verificar si como argumento se pasa la palabra “help”
if [ "$1" == "-help" ]; then
   if [ -f "$HELP_FILE" ]; then
      cat "$HELP_FILE"
   else
      echo "Error: No se encuentra el archivo de ayuda en $HELP_FILE"
   fi
   exit 0

# Valida si hay dos argumentos.
elif [ $# -ne 2 ]; then
	echo "Error: Se deben pasar exactamente dos argumentos: origen y destino."
	echo "Use '$0 -help' para más información."
	exit 1
fi

# Validar que directorios de origen y destino estén disponibles
if [ ! -d "$1" ]; then
	echo "Error: El directorio de origen '$1' no existe o no es un directorio válido."
	exit 1
elif [ ! -d "$2" ]; then
	echo "Error: El directorio de destino '$2' no existe o no es un directorio válido."
	exit 1
fi

# Fecha en formato ANSI (YYYYMMDD)
FECHA=$(date +%Y%m%d)

# Nombre del archivo de backup
BACKUP=$(basename "$1")_bkp_$FECHA.tar.gz

# Crear el backup
tar -czf "$2/$BACKUP" -C "$1" .

# Verificar si el backup se creó correctamente
if [ -f "$2/$BACKUP" ]; then
	echo "Backup creado exitosamente: $2/$BACKUP"
else
	echo "Error: No se pudo crear el backup."
	exit 1
fi

